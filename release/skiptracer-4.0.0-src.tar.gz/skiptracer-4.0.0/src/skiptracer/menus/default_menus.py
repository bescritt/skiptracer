# -*- coding: utf-8 -*-
#!/usr/bin/env python
from __future__ import print_function
from .help_menu import HelpMenu
from ..colors.default_colors import DefaultBodyColors as bc
from ..plugins import proxygrabber as pg

import sys
import configparser
import ast
import builtins as bi

from ..plugins.base import _package_path


class DefaultMenus:
    plugin_list = {}
    config = []
    emodules = []
    nmodules = []
    pmodules = []
    snmodules = []
    plmodules = []
    search_string = ''

    default_items = [
        {'key': 'all', 'text': 'All - Run all modules associated with this group'},
        {'key': 'back', 'text': 'Back - Return to main menu'},
        {'key': 'exit', 'text': 'Exit - Terminate the application'}
    ]

    ltypes = [
        {'key': 'proxy', 'text': 'Proxy - Set a request proxy'},
        {'key': 'email', 'text': 'Email - Search targets by email address'},
        {'key': 'name', 'text': 'Name - Search targets by First Last name combination'},
        {'key': 'phone', 'text': 'Phone - Search targets by telephone number'},
        {'key': 'screen', 'text': 'Screen Name - Search targets by known alias'},
        {'key': 'license', 'text': 'License Plate - Search targets by license plate'},
        {'key': 'profiler', 'text': 'Profiler - A "Guess Who" Q&A interactive user interface'},
        {'key': 'help', 'text': 'Help - Details the application and use cases'},
        {'key': 'exit', 'text': 'Exit - Terminate the application'}
    ]

    def __init__(self, plugins):
        """Get a list of plugins."""
        self.plugin_list = plugins
        self.config = configparser.ConfigParser()
        self.config.read(_package_path('skiptracer.cfg'))

    def useproxy(self):
        """Generate a new proxy for masking requests."""
        if str(bi.webproxy).lower() == "y":
            bi.proxy = pg.new_proxy()
            return True
        else:
            return False

    def helpmenu(self):
        """Display help text to user."""
        HelpMenu()

    def intromenu(self):
        """Top level intro menu."""
        self.search_string = ""
        bi.lookup = ''
        if self.useproxy():
            print("\t  [" + bc.CRED + "::ATTENTION::" + bc.CEND + "]" +
                  bc.CYLW + " Proxied requests are unreliable " + bc.CEND +
                  "[" + bc.CRED + "::ATTENTION::" + bc.CEND + "]")

        gselect = ""
        while gselect == "":
            for i, v in enumerate(self.ltypes):
                print('[' + str(i + 1) + '] -' + self.ltypes[i]['text'])

            try:
                selection = int(input("[!] Lookup menu - Please select a number:"))
                gselect = self.ltypes[selection - 1]['key']
            except (ValueError, EOFError, KeyboardInterrupt) as failselect:
                if isinstance(failselect, (EOFError, KeyboardInterrupt)):
                    print("\n [!] Input closed -- exiting.")
                    sys.exit(0)
                print("Please use an integer value for your selection!")

        if gselect == "exit":
            sys.exit()
        if gselect == "proxy":
            self.proxymenu()
        if gselect == "email":
            self.emailmenu()
        if gselect == "name":
            self.namemenu()
        if gselect == "phone":
            self.phonemenu()
        if gselect == "screen":
            self.snmenu()
        if gselect == "license":
            self.platemenu()
        if gselect == "profiler":
            self.profiler()
        if gselect == "help":
            self.helpmenu()

    def grabplugins(self, plugin_type, plugin_list):
        """Grab a list of relevant plugins."""
        for i in plugin_list:
            tc = ast.literal_eval(plugin_list[i])
            plugin_type.append({'key': i, 'text': tc[0] + " - " + tc[1]})

        return plugin_type + self.default_items

    def grabuserchoice(self, plugin_type, textsub):
        """Grab user choice."""
        gselect = ""

        print(" [!] " + textsub + " search menu - Please select a number")

        for i, v in enumerate(plugin_type):
            print(' [' + str(i + 1) + '] -' + plugin_type[i]['text'])

        try:
            selection = int(input(" [!] Select a number to continue: "))
            gselect = plugin_type[selection - 1]['key']
        except (ValueError, EOFError, KeyboardInterrupt) as failselect:
            if isinstance(failselect, (EOFError, KeyboardInterrupt)):
                print("\n [!] Input closed -- exiting.")
                sys.exit(0)
            print("Please use an integer value for your selection!")

        return gselect

    def selectchoice(self, menu, mtype, error, plugins, gselect):
        """Select a menu item and then action it."""
        if gselect == "":
            menu()
        if gselect == "exit":
            sys.exit()
        if gselect == "back":
            self.intromenu()

        if not self.search_string or self.search_string == '':
            self.search_string = input(error)

        print()
        self.useproxy()
        if gselect != "all":
            self.plugin_list[gselect]().get_info(self.search_string, mtype)

        if gselect == "all":
            for i in plugins:
                self.plugin_list[i]().get_info(self.search_string, mtype)
        menu()

    def proxymenu(self):
        """Set a proxy for requests."""
        print("proxy menu")

    def emailmenu(self):
        """Display the email modules to the user."""
        self.emodules = []
        self.emodules = self.grabplugins(self.emodules, self.config['menu.email'])
        gselect = self.grabuserchoice(self.emodules, "E-Mail")

        self.selectchoice(
            self.emailmenu,
            "email",
            "[What is the marks email address? - ex: username@domain.tld]:",
            self.config['menu.email'],
            gselect
        )

    def namemenu(self):
        """Print menu for name matching plugins."""
        self.nmodules = []
        self.nmodules = self.grabplugins(self.nmodules, self.config['menu.name'])
        gselect = self.grabuserchoice(self.nmodules, "Name")

        self.selectchoice(
            self.namemenu,
            "name",
            "[What is the marks name? - ex: First Lastname]: ",
            self.config['menu.name'],
            gselect
        )

    def phonemenu(self):
        """Display the phone menu to the user."""
        self.pmodules = []
        self.pmodules = self.grabplugins(self.pmodules, self.config['menu.phone'])
        gselect = self.grabuserchoice(self.pmodules, "Phone")

        self.selectchoice(
            self.phonemenu,
            "phone",
            "[What is the marks phone number? - ex: 1234567890]: ",
            self.config['menu.phone'],
            gselect
        )

    def snmenu(self):
        """Screen Name grabbing tools menu."""
        self.snmodules = self.grabplugins(self.snmodules, self.config['menu.screenname'])
        gselect = self.grabuserchoice(self.snmodules, "Screen Name")

        self.selectchoice(
            self.snmenu,
            "screenname",
            "[What is the marks screenname? - ex: (Ac1dBurn|Zer0Cool)]: ",
            self.config['menu.screenname'],
            gselect
        )

    def platemenu(self):
        """Enter a plate number."""
        self.plmodules = self.grabplugins(self.plmodules, self.config['menu.plate'])
        gselect = self.grabuserchoice(self.plmodules, "Plate Number")

        self.selectchoice(
            self.platemenu,
            "plate",
            "[What is the marks vehicle plate number? - ex: (XYZ123|0U812)]: ",
            self.config['menu.plate'],
            gselect
        )

    def profiler(self):
        """Profiler output - guess who interactive interface."""
        fname = input("\t[Whats the users first name? - ex: Alice]: ")
        lname = input("\t[Whats the users last name? - ex: Smith]: ")
        bi.name = fname + " " + lname
        bi.agerange = input("\t[Whats the marks age range? - ex: 18-100]: ")
        bi.apprage = input("\t[Whats the marks suspected age? - ex: 18]: ")
        bi.state = input(
            "\t[Whats state does the mark live in? - ex: (FL|Florida)]: ")
        bi.city = input(
            "\t[Whats city does the mark live in? - ex: Orlando]: ")
        bi.zip = input(
            "\t[Whats the zipcode the mark lives in? - ex: 12345]: ")
        bi.phone = input(
            "\t[What is a known phone number for the mark? - ex: 1234567890]: ")
        bi.screenname = input(
            "\t[What are the known aliasis of the mark? - ex: (Ac1dBurn|Zer0cool)]: ")
        bi.plate = input(
            "\t[Does the mark have a known license plate? - ex: (ABC1234|XYZ123)]: ")
        bi.email = input(
            "\t[What is the marks email address? - ex: username@domain.tld]: ")
